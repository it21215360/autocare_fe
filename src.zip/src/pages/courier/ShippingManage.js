import React  from "react";
import "./ShippingManage.css";



function ShippingManage () {


    return (
      <div className="deliveryreq">

      <h2>Delivery Requests</h2>

<div className="box">
   
     <h5>Delivery ID :</h5>
  
     </div>
    
    

</div>   



    )
     }



export default ShippingManage
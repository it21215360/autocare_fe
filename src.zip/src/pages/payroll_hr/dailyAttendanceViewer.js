import { GroupItem } from 'devextreme-react/form';
import React from 'react';
import { Button } from 'react-bootstrap';

function AttendanceViewer() {
    return(
        <div className={'content-block'}>
        <h2> Employee Daily Attendance Viewer</h2>
        
                  
       </div>
    )
}

export default AttendanceViewer
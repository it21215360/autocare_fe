const appInfo = {
    title: 'AutoCare Web'
};
export default appInfo;

